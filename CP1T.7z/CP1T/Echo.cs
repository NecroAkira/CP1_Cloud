using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace CP1
{
    public class Echo
    {
        private readonly ILogger _logger;

        public Echo(ILogger<Echo> logger)
        {
            _logger = logger;
        }

        [Function("Echo")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req,
            FunctionContext executionContext)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "text/plain; charset=utf-8");

            // Realiza a verificação das portas específicas
            string result = await CheckSpecifiedPorts("cp.leosantos.seg.br");
            response.WriteString(result);

            return response;
        }

        private async Task<string> CheckSpecifiedPorts(string host)
        {
            string result = "Open ports:\n";

            try
            {
                IPHostEntry hostEntry = await Dns.GetHostEntryAsync(host);
                foreach (var portInfo in new List<(int Port, string Service)>()
                {
                    (22, "SSH"),
                    (8080, "HTTP Proxy"),
                    (30000, "NDMP"),
                    (30718, "Unknown"),
                    (30951, "Unknown"),
                    (31038, "Unknown")
                })
                {
                    try
                    {
                        using (TcpClient tcpClient = new TcpClient())
                        {
                            await tcpClient.ConnectAsync(host, portInfo.Port);
                            result += $"Port {portInfo.Port} ({portInfo.Service}) is open\n";
                        }
                    }
                    catch (Exception)
                    {
                        // Porta está fechada ou ocorreu um erro ao tentar conectar
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error checking open ports: {ex.Message}");
                result = "Error checking open ports\n";
            }

            return result;
        }
    }
}
